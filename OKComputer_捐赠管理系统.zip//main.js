// Sri Mandir Temple Donation Platform - Main JavaScript File
// Comprehensive functionality for donation processing, admin management, and user interactions

// Global variables and configuration
let currentDonationStep = 1;
let selectedAmount = 0;
let donationData = {};
let particleSystem = null;

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// Main initialization function
function initializeApp() {
    initializeNavigation();
    initializeDonationForm();
    initializeAnimations();
    initializeParticleSystem();
    initializeScrollAnimations();
    initializeMobileMenu();
    
    // Page-specific initializations
    if (document.getElementById('particles-container')) {
        initializeHeroParticles();
    }
    
    console.log('Sri Mandir Donation Platform initialized successfully');
}

// Navigation functionality
function initializeNavigation() {
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Active navigation highlighting
    window.addEventListener('scroll', updateActiveNavigation);
}

function updateActiveNavigation() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('nav a[href^="#"]');
    
    let current = '';
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        if (window.pageYOffset >= sectionTop) {
            current = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.classList.remove('text-primary-saffron', 'font-semibold');
        if (link.getAttribute('href') === `#${current}`) {
            link.classList.add('text-primary-saffron', 'font-semibold');
        }
    });
}

// Mobile menu functionality
function initializeMobileMenu() {
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const nav = document.querySelector('nav');
    
    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', function() {
            // Toggle mobile menu (simplified for demo)
            alert('Mobile menu would open here in a real application');
        });
    }
}

// Donation form functionality
function initializeDonationForm() {
    // Amount selection
    document.querySelectorAll('.amount-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove selection from all buttons
            document.querySelectorAll('.amount-btn').forEach(b => b.classList.remove('selected'));
            // Add selection to clicked button
            this.classList.add('selected');
            selectedAmount = parseInt(this.dataset.amount);
            // Clear custom amount
            const customInput = document.getElementById('custom-amount');
            if (customInput) customInput.value = '';
        });
    });
    
    // Custom amount input
    const customAmountInput = document.getElementById('custom-amount');
    if (customAmountInput) {
        customAmountInput.addEventListener('input', function() {
            // Clear selection from preset buttons
            document.querySelectorAll('.amount-btn').forEach(b => b.classList.remove('selected'));
            selectedAmount = parseInt(this.value) || 0;
        });
    }
    
    // Payment method selection
    document.querySelectorAll('.payment-method').forEach(method => {
        method.addEventListener('click', function() {
            document.querySelectorAll('.payment-method').forEach(m => {
                m.classList.remove('border-primary-saffron', 'bg-primary-saffron', 'text-white');
                m.classList.add('border-gray-300');
            });
            this.classList.remove('border-gray-300');
            this.classList.add('border-primary-saffron', 'bg-primary-saffron', 'text-white');
        });
    });
}

// Donation form step navigation
function nextStep() {
    if (validateCurrentStep()) {
        currentDonationStep++;
        updateDonationStep();
        saveDonationProgress();
    }
}

function prevStep() {
    currentDonationStep--;
    updateDonationStep();
}

function updateDonationStep() {
    // Hide all steps
    document.querySelectorAll('.donation-step').forEach(step => {
        step.classList.remove('active');
    });
    
    // Show current step
    const currentStepElement = document.getElementById(`step-${currentDonationStep}`);
    if (currentStepElement) {
        currentStepElement.classList.add('active');
    }
    
    // Update progress indicator
    updateProgressIndicator();
}

function updateProgressIndicator() {
    const progressSteps = document.querySelectorAll('.flex.items-center .w-8');
    progressSteps.forEach((step, index) => {
        if (index < currentDonationStep) {
            step.classList.add('bg-primary-saffron', 'text-white');
            step.classList.remove('bg-gray-300', 'text-gray-600');
        } else {
            step.classList.add('bg-gray-300', 'text-gray-600');
            step.classList.remove('bg-primary-saffron', 'text-white');
        }
    });
}

function validateCurrentStep() {
    switch (currentDonationStep) {
        case 1:
            if (selectedAmount <= 0) {
                showNotification('Please select a donation amount', 'error');
                return false;
            }
            donationData.amount = selectedAmount;
            donationData.anonymous = document.getElementById('anonymous')?.checked || false;
            break;
            
        case 2:
            const name = document.getElementById('donor-name')?.value;
            const email = document.getElementById('donor-email')?.value;
            const phone = document.getElementById('donor-phone')?.value;
            
            if (!name || !email || !phone) {
                showNotification('Please fill in all required fields', 'error');
                return false;
            }
            
            if (!isValidEmail(email)) {
                showNotification('Please enter a valid email address', 'error');
                return false;
            }
            
            donationData.name = name;
            donationData.email = email;
            donationData.phone = phone;
            donationData.address = document.getElementById('donor-address')?.value;
            donationData.message = document.getElementById('donor-message')?.value;
            break;
            
        case 3:
            const selectedPayment = document.querySelector('.payment-method.border-primary-saffron');
            if (!selectedPayment) {
                showNotification('Please select a payment method', 'error');
                return false;
            }
            donationData.paymentMethod = selectedPayment.dataset.method;
            break;
    }
    return true;
}

// Process donation
function processDonation() {
    if (validateCurrentStep()) {
        // Show loading state
        showLoadingState();
        
        // Simulate payment processing
        setTimeout(() => {
            hideLoadingState();
            completeDonation();
        }, 3000);
    }
}

function completeDonation() {
    // Generate donation ID
    const donationId = 'DON' + Date.now().toString().slice(-6);
    donationData.id = donationId;
    donationData.date = new Date().toISOString();
    donationData.status = 'completed';
    
    // Save donation to local storage (in real app, this would be sent to server)
    saveDonationToStorage(donationData);
    
    // Generate and download receipt
    generateReceipt(donationData);
    
    // Show success message
    showDonationSuccess(donationData);
    
    // Clear form
    resetDonationForm();
    
    // Update progress displays
    updateProgressDisplays();
}

function showDonationSuccess(data) {
    const successMessage = `
        <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50" onclick="this.remove()">
            <div class="bg-white rounded-2xl p-8 max-w-md mx-4 text-center" onclick="event.stopPropagation()">
                <div class="text-6xl mb-4">🙏</div>
                <h3 class="font-display text-2xl font-bold mb-4 text-primary-saffron">Donation Successful!</h3>
                <p class="text-gray-600 mb-4">Thank you for your generous contribution of <strong>₹${data.amount.toLocaleString()}</strong></p>
                <p class="text-sm text-gray-500 mb-6">Donation ID: ${data.id}</p>
                <div class="space-y-3">
                    <button onclick="downloadReceipt()" class="w-full bg-primary-saffron text-white py-3 rounded-lg font-semibold hover:bg-opacity-90 transition-colors">
                        📄 Download Receipt
                    </button>
                    <button onclick="this.closest('.fixed').remove()" class="w-full border-2 border-gray-300 py-3 rounded-lg font-semibold hover:bg-gray-50 transition-colors">
                        Continue
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', successMessage);
}

// Receipt generation
function generateReceipt(data) {
    const receiptData = {
        ...data,
        templeName: 'Sri Mandir Trust',
        address: 'Temple Road, Sacred City',
        phone: '+91 98765 43210',
        email: 'info@srimandir.org',
        pan: 'AACTS1234F',
        registration: 'TRUST/2024/001'
    };
    
    // Store receipt data for download
    localStorage.setItem('lastDonationReceipt', JSON.stringify(receiptData));
}

function downloadReceipt() {
    const receiptData = JSON.parse(localStorage.getItem('lastDonationReceipt') || '{}');
    if (receiptData.id) {
        alert(`Generating PDF receipt for donation ${receiptData.id}... (This would create and download a professional PDF receipt in a real application)`);
    } else {
        alert('No receipt data found. Please complete a donation first.');
    }
}

// Local storage functions
function saveDonationProgress() {
    localStorage.setItem('donationProgress', JSON.stringify({
        step: currentDonationStep,
        data: donationData
    }));
}

function loadDonationProgress() {
    const saved = localStorage.getItem('donationProgress');
    if (saved) {
        const progress = JSON.parse(saved);
        currentDonationStep = progress.step;
        donationData = progress.data;
        updateDonationStep();
    }
}

function saveDonationToStorage(donation) {
    const donations = JSON.parse(localStorage.getItem('donations') || '[]');
    donations.push(donation);
    localStorage.setItem('donations', JSON.stringify(donations));
}

function getDonations() {
    return JSON.parse(localStorage.getItem('donations') || '[]');
}

function resetDonationForm() {
    currentDonationStep = 1;
    selectedAmount = 0;
    donationData = {};
    
    // Clear form fields
    document.querySelectorAll('#donation input, #donation textarea').forEach(input => {
        input.value = '';
        input.checked = false;
    });
    
    // Reset selections
    document.querySelectorAll('.amount-btn, .payment-method').forEach(btn => {
        btn.classList.remove('selected', 'border-primary-saffron', 'bg-primary-saffron', 'text-white');
        btn.classList.add('border-gray-300');
    });
    
    updateDonationStep();
    localStorage.removeItem('donationProgress');
}

// Utility functions
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `fixed top-20 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm ${
        type === 'error' ? 'bg-red-500 text-white' : 
        type === 'success' ? 'bg-green-500 text-white' : 
        'bg-blue-500 text-white'
    }`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animate in
    anime({
        targets: notification,
        translateX: [300, 0],
        opacity: [0, 1],
        duration: 300,
        easing: 'easeOutCubic'
    });
    
    // Remove after 3 seconds
    setTimeout(() => {
        anime({
            targets: notification,
            translateX: 300,
            opacity: 0,
            duration: 300,
            easing: 'easeInCubic',
            complete: () => notification.remove()
        });
    }, 3000);
}

function showLoadingState() {
    const loadingOverlay = document.createElement('div');
    loadingOverlay.id = 'loading-overlay';
    loadingOverlay.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    loadingOverlay.innerHTML = `
        <div class="bg-white rounded-2xl p-8 text-center">
            <div class="animate-spin w-12 h-12 border-4 border-primary-saffron border-t-transparent rounded-full mx-auto mb-4"></div>
            <h3 class="font-display text-xl font-semibold mb-2">Processing Donation</h3>
            <p class="text-gray-600">Please wait while we process your generous contribution...</p>
        </div>
    `;
    document.body.appendChild(loadingOverlay);
}

function hideLoadingState() {
    const loadingOverlay = document.getElementById('loading-overlay');
    if (loadingOverlay) {
        loadingOverlay.remove();
    }
}

// Animation functions
function initializeAnimations() {
    // Initialize scroll reveal animations
    initializeRevealAnimations();
    
    // Initialize floating animations
    initializeFloatingAnimations();
    
    // Initialize button hover effects
    initializeButtonEffects();
}

function initializeRevealAnimations() {
    const revealElements = document.querySelectorAll('.reveal-up');
    
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('revealed');
            }
        });
    }, { 
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    revealElements.forEach(element => {
        revealObserver.observe(element);
    });
}

function initializeFloatingAnimations() {
    // Add floating animation to elements with floating-animation class
    const floatingElements = document.querySelectorAll('.floating-animation');
    floatingElements.forEach((element, index) => {
        anime({
            targets: element,
            translateY: [-10, 10],
            duration: 3000 + (index * 200),
            direction: 'alternate',
            loop: true,
            easing: 'easeInOutSine'
        });
    });
}

function initializeButtonEffects() {
    document.querySelectorAll('.btn-primary, .btn-admin').forEach(button => {
        button.addEventListener('mouseenter', function() {
            anime({
                targets: this,
                scale: 1.05,
                duration: 200,
                easing: 'easeOutCubic'
            });
        });
        
        button.addEventListener('mouseleave', function() {
            anime({
                targets: this,
                scale: 1,
                duration: 200,
                easing: 'easeOutCubic'
            });
        });
    });
}

function initializeScrollAnimations() {
    // Parallax effect for hero section
    window.addEventListener('scroll', () => {
        const scrolled = window.pageYOffset;
        const parallaxElements = document.querySelectorAll('[data-parallax]');
        
        parallaxElements.forEach(element => {
            const speed = element.dataset.parallax || 0.5;
            const yPos = -(scrolled * speed);
            element.style.transform = `translateY(${yPos}px)`;
        });
    });
}

// Particle system for hero section
function initializeParticleSystem() {
    if (typeof p5 !== 'undefined' && document.getElementById('particles-container')) {
        new p5(particleSketch, 'particles-container');
    }
}

function particleSketch(p) {
    let particles = [];
    
    p.setup = function() {
        const canvas = p.createCanvas(window.innerWidth, window.innerHeight);
        canvas.style('position', 'absolute');
        canvas.style('top', '0');
        canvas.style('left', '0');
        canvas.style('z-index', '1');
        
        // Create particles
        for (let i = 0; i < 50; i++) {
            particles.push(new Particle(p));
        }
    };
    
    p.draw = function() {
        p.clear();
        
        // Update and display particles
        particles.forEach(particle => {
            particle.update();
            particle.display();
        });
    };
    
    p.windowResized = function() {
        p.resizeCanvas(window.innerWidth, window.innerHeight);
    };
    
    class Particle {
        constructor(p) {
            this.p = p;
            this.x = p.random(p.width);
            this.y = p.random(p.height);
            this.vx = p.random(-0.5, 0.5);
            this.vy = p.random(-0.5, 0.5);
            this.size = p.random(2, 6);
            this.opacity = p.random(0.3, 0.8);
            this.color = p.random(['#FF6B35', '#D4AF37', '#FDF6E3']);
        }
        
        update() {
            this.x += this.vx;
            this.y += this.vy;
            
            // Wrap around edges
            if (this.x < 0) this.x = this.p.width;
            if (this.x > this.p.width) this.x = 0;
            if (this.y < 0) this.y = this.p.height;
            if (this.y > this.p.height) this.y = 0;
            
            // Gentle floating motion
            this.x += Math.sin(this.p.frameCount * 0.01) * 0.2;
            this.y += Math.cos(this.p.frameCount * 0.01) * 0.2;
        }
        
        display() {
            this.p.fill(this.color + Math.floor(this.opacity * 255).toString(16));
            this.p.noStroke();
            this.p.ellipse(this.x, this.y, this.size);
        }
    }
}

// Hero particles initialization
function initializeHeroParticles() {
    // This would initialize additional particle effects specifically for the hero section
    console.log('Hero particles initialized');
}

// Progress display updates
function updateProgressDisplays() {
    const donations = getDonations();
    const totalAmount = donations.reduce((sum, donation) => sum + donation.amount, 0);
    const targetAmount = 2500000; // ₹25,00,000
    const progressPercentage = (totalAmount / targetAmount) * 100;
    
    // Update progress bars and displays
    const progressElements = document.querySelectorAll('[data-progress]');
    progressElements.forEach(element => {
        element.style.width = `${progressPercentage}%`;
    });
    
    // Update amount displays
    const amountElements = document.querySelectorAll('[data-total-amount]');
    amountElements.forEach(element => {
        element.textContent = `₹${totalAmount.toLocaleString()}`;
    });
    
    // Update percentage displays
    const percentageElements = document.querySelectorAll('[data-progress-percentage]');
    percentageElements.forEach(element => {
        element.textContent = `${progressPercentage.toFixed(1)}%`;
    });
}

// Scroll to donation section
function scrollToDonation() {
    const donationSection = document.getElementById('donation');
    if (donationSection) {
        donationSection.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// Admin functions (for admin.html)
function initializeAdminFunctions() {
    if (document.getElementById('admin-dashboard')) {
        initializeAdminCharts();
        loadAdminData();
    }
}

function initializeAdminCharts() {
    // This would initialize charts for the admin dashboard
    console.log('Admin charts initialized');
}

function loadAdminData() {
    const donations = getDonations();
    // Update admin dashboard with real data
    updateAdminDisplays(donations);
}

function updateAdminDisplays(donations) {
    // Update various admin dashboard displays with real donation data
    const totalDonors = new Set(donations.map(d => d.email)).size;
    const totalAmount = donations.reduce((sum, d) => sum + d.amount, 0);
    const averageDonation = totalAmount / donations.length || 0;
    
    // Update display elements
    const displays = {
        totalAmount: `₹${totalAmount.toLocaleString()}`,
        totalDonors: totalDonors.toString(),
        averageDonation: `₹${Math.round(averageDonation).toLocaleString()}`,
        progressPercentage: `${((totalAmount / 2500000) * 100).toFixed(1)}%`
    };
    
    Object.entries(displays).forEach(([key, value]) => {
        const element = document.querySelector(`[data-${key}]`);
        if (element) {
            element.textContent = value;
        }
    });
}

// Utility function to format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(amount);
}

// Utility function to format date
function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Export functions for global access
window.scrollToDonation = scrollToDonation;
window.nextStep = nextStep;
window.prevStep = prevStep;
window.processDonation = processDonation;
window.downloadReceipt = downloadReceipt;

// Initialize additional features when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    loadDonationProgress();
    updateProgressDisplays();
    initializeAdminFunctions();
    
    // Add smooth page transitions
    document.body.style.opacity = '0';
    anime({
        targets: document.body,
        opacity: 1,
        duration: 500,
        easing: 'easeOutCubic'
    });
});

// Handle page visibility changes
document.addEventListener('visibilitychange', function() {
    if (document.hidden) {
        // Page is hidden, pause animations
        console.log('Page hidden - pausing animations');
    } else {
        // Page is visible, resume animations
        console.log('Page visible - resuming animations');
    }
});

// Error handling
window.addEventListener('error', function(e) {
    console.error('Application error:', e.error);
    showNotification('An error occurred. Please refresh the page.', 'error');
});

// Service worker registration (for offline functionality)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('ServiceWorker registration successful');
            })
            .catch(function(err) {
                console.log('ServiceWorker registration failed');
            });
    });
}

console.log('Sri Mandir Donation Platform - Main JavaScript loaded successfully');